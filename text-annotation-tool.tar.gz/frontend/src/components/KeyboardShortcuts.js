import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function KeyboardShortcuts({ 
  annotations, 
  selectedAnnotation, 
  setSelectedAnnotation, 
  provideFeedback,
  createAnnotation,
  updateAnnotation,
  selectedText,
  annotationText,
  deleteAnnotation,
  navigateToNextDocument,
  navigateToPreviousDocument
}) {
  const navigate = useNavigate();

  useEffect(() => {
    const handleKeyDown = (e) => {
      // Skip if user is typing in an input field
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
        return;
      }

      // Navigation between annotations
      if (e.key === 'j' || e.key === 'J') {
        // Next annotation
        if (annotations.length > 0) {
          if (!selectedAnnotation) {
            setSelectedAnnotation(annotations[0]);
          } else {
            const currentIndex = annotations.findIndex(a => a.id === selectedAnnotation.id);
            if (currentIndex < annotations.length - 1) {
              setSelectedAnnotation(annotations[currentIndex + 1]);
            }
          }
        }
        e.preventDefault();
      } else if (e.key === 'k' || e.key === 'K') {
        // Previous annotation
        if (annotations.length > 0 && selectedAnnotation) {
          const currentIndex = annotations.findIndex(a => a.id === selectedAnnotation.id);
          if (currentIndex > 0) {
            setSelectedAnnotation(annotations[currentIndex - 1]);
          }
        }
        e.preventDefault();
      }

      // Save annotation
      if ((e.ctrlKey || e.metaKey) && (e.key === 's' || e.key === 'S')) {
        if (selectedAnnotation) {
          updateAnnotation();
        } else if (selectedText) {
          createAnnotation();
        }
        e.preventDefault();
      }

      // Provide feedback
      if (selectedAnnotation) {
        if (e.key === 'c' || e.key === 'C') {
          // Mark as correct
          provideFeedback(selectedAnnotation.id, true);
          e.preventDefault();
        } else if (e.key === 'x' || e.key === 'X') {
          // Mark as incorrect
          provideFeedback(selectedAnnotation.id, false);
          e.preventDefault();
        } else if (e.key === 'd' || e.key === 'D') {
          // Delete annotation
          if (window.confirm('Are you sure you want to delete this annotation?')) {
            deleteAnnotation(selectedAnnotation.id);
          }
          e.preventDefault();
        }
      }

      // Navigation between documents
      if ((e.ctrlKey || e.metaKey) && e.key === 'ArrowLeft') {
        if (navigateToPreviousDocument) {
          navigateToPreviousDocument();
        } else {
          navigate('/documents');
        }
        e.preventDefault();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'ArrowRight') {
        if (navigateToNextDocument) {
          navigateToNextDocument();
        }
        e.preventDefault();
      }

      // Escape to cancel selection
      if (e.key === 'Escape') {
        if (selectedAnnotation) {
          setSelectedAnnotation(null);
        }
        window.getSelection().removeAllRanges();
        e.preventDefault();
      }

      // Tab to cycle through annotations
      if (e.key === 'Tab') {
        if (annotations.length > 0) {
          if (!selectedAnnotation) {
            setSelectedAnnotation(annotations[0]);
          } else {
            const currentIndex = annotations.findIndex(a => a.id === selectedAnnotation.id);
            const nextIndex = (currentIndex + 1) % annotations.length;
            setSelectedAnnotation(annotations[nextIndex]);
          }
        }
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [
    annotations, 
    selectedAnnotation, 
    setSelectedAnnotation, 
    provideFeedback, 
    createAnnotation, 
    updateAnnotation, 
    selectedText,
    annotationText,
    deleteAnnotation,
    navigateToNextDocument,
    navigateToPreviousDocument,
    navigate
  ]);

  return null; // This component doesn't render anything
}

export default KeyboardShortcuts;
