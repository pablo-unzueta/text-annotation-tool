import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Row, Col, Button, Form, Card, Badge, Alert } from 'react-bootstrap';
import axios from 'axios';
import { FaCheck, FaTimes, FaTrash, FaEdit } from 'react-icons/fa';
import KeyboardShortcuts from './KeyboardShortcuts';
import AnnotationFilter from './AnnotationFilter';
import AnnotationSorter from './AnnotationSorter';

function DocumentView() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [document, setDocument] = useState(null);
  const [annotations, setAnnotations] = useState([]);
  const [filteredAnnotations, setFilteredAnnotations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedText, setSelectedText] = useState('');
  const [selectionRange, setSelectionRange] = useState({ start: 0, end: 0 });
  const [annotationText, setAnnotationText] = useState('');
  const [selectedAnnotation, setSelectedAnnotation] = useState(null);
  const [category, setCategory] = useState('');
  const textContentRef = useRef(null);

  // Fetch document and its annotations
  useEffect(() => {
    const fetchDocumentAndAnnotations = async () => {
      try {
        setLoading(true);
        const [docResponse, annotationsResponse] = await Promise.all([
          axios.get(`/api/documents/${id}`),
          axios.get(`/api/annotations/?document_id=${id}`)
        ]);
        
        setDocument(docResponse.data);
        setAnnotations(annotationsResponse.data);
        setFilteredAnnotations(annotationsResponse.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('Error loading document. Please try again.');
        setLoading(false);
      }
    };

    fetchDocumentAndAnnotations();
  }, [id]);

  // Handle text selection
  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const textContent = textContentRef.current;
      
      if (textContent && textContent.contains(range.commonAncestorContainer)) {
        const content = document.content;
        const preSelectionRange = range.cloneRange();
        preSelectionRange.selectNodeContents(textContent);
        preSelectionRange.setEnd(range.startContainer, range.startOffset);
        const start = preSelectionRange.toString().length;
        
        const selectedText = range.toString().trim();
        if (selectedText.length > 0) {
          setSelectedText(selectedText);
          setSelectionRange({ 
            start, 
            end: start + selectedText.length 
          });
          setSelectedAnnotation(null);
          setAnnotationText('');
        }
      }
    }
  };

  // Create a new annotation
  const createAnnotation = async () => {
    if (!selectedText || selectedText.length === 0) {
      return;
    }

    try {
      const response = await axios.post('/api/annotations/', {
        document_id: parseInt(id),
        start_offset: selectionRange.start,
        end_offset: selectionRange.end,
        selected_text: selectedText,
        annotation_text: annotationText,
        category: category || null
      });
      
      const newAnnotation = response.data;
      setAnnotations([...annotations, newAnnotation]);
      setFilteredAnnotations([...filteredAnnotations, newAnnotation]);
      setSelectedText('');
      setAnnotationText('');
      setCategory('');
      window.getSelection().removeAllRanges();
    } catch (error) {
      console.error('Error creating annotation:', error);
      setError('Error creating annotation. Please try again.');
    }
  };

  // Update an existing annotation
  const updateAnnotation = async () => {
    if (!selectedAnnotation) return;
    
    try {
      const response = await axios.put(`/api/annotations/${selectedAnnotation.id}`, {
        ...selectedAnnotation,
        annotation_text: annotationText,
        category: category || selectedAnnotation.category
      });
      
      const updatedAnnotation = response.data;
      
      setAnnotations(annotations.map(ann => 
        ann.id === selectedAnnotation.id ? updatedAnnotation : ann
      ));
      
      setFilteredAnnotations(filteredAnnotations.map(ann => 
        ann.id === selectedAnnotation.id ? updatedAnnotation : ann
      ));
      
      setSelectedAnnotation(null);
      setAnnotationText('');
      setCategory('');
    } catch (error) {
      console.error('Error updating annotation:', error);
      setError('Error updating annotation. Please try again.');
    }
  };

  // Delete an annotation
  const deleteAnnotation = async (annotationId) => {
    try {
      await axios.delete(`/api/annotations/${annotationId}`);
      
      setAnnotations(annotations.filter(ann => ann.id !== annotationId));
      setFilteredAnnotations(filteredAnnotations.filter(ann => ann.id !== annotationId));
      
      if (selectedAnnotation && selectedAnnotation.id === annotationId) {
        setSelectedAnnotation(null);
        setAnnotationText('');
        setCategory('');
      }
    } catch (error) {
      console.error('Error deleting annotation:', error);
      setError('Error deleting annotation. Please try again.');
    }
  };

  // Provide quick feedback (correct/incorrect)
  const provideFeedback = async (annotationId, isCorrect) => {
    try {
      await axios.post(`/api/annotations/${annotationId}/feedback?is_correct=${isCorrect}`);
      
      const updatedAnnotations = annotations.map(ann => 
        ann.id === annotationId ? { ...ann, is_correct: isCorrect } : ann
      );
      
      setAnnotations(updatedAnnotations);
      setFilteredAnnotations(filteredAnnotations.map(ann => 
        ann.id === annotationId ? { ...ann, is_correct: isCorrect } : ann
      ));
    } catch (error) {
      console.error('Error providing feedback:', error);
      setError('Error providing feedback. Please try again.');
    }
  };

  // Select an annotation for editing
  const selectAnnotation = (annotation) => {
    setSelectedAnnotation(annotation);
    setAnnotationText(annotation.annotation_text || '');
    setCategory(annotation.category || '');
    setSelectedText('');
  };

  // Handle filter changes
  const handleFilterChange = (filters) => {
    let filtered = [...annotations];
    
    if (filters.isCorrect !== null) {
      filtered = filtered.filter(ann => ann.is_correct === filters.isCorrect);
    }
    
    if (filters.category) {
      filtered = filtered.filter(ann => ann.category === filters.category);
    }
    
    if (filters.createdBy) {
      filtered = filtered.filter(ann => ann.created_by === filters.createdBy);
    }
    
    setFilteredAnnotations(filtered);
  };

  // Handle sort changes
  const handleSortChange = (sortedAnnotations) => {
    setFilteredAnnotations(sortedAnnotations);
  };

  // Render document content with highlighted annotations
  const renderDocumentContent = () => {
    if (!document) return null;
    
    const content = document.content;
    const sortedAnnotations = [...annotations].sort((a, b) => a.start_offset - b.start_offset);
    
    let lastIndex = 0;
    const contentParts = [];
    
    sortedAnnotations.forEach((annotation, index) => {
      // Add text before the annotation
      if (annotation.start_offset > lastIndex) {
        contentParts.push(content.substring(lastIndex, annotation.start_offset));
      }
      
      // Add the highlighted annotation
      const highlightClass = `highlight ${selectedAnnotation && selectedAnnotation.id === annotation.id ? 'selected' : ''} ${annotation.is_correct === true ? 'correct' : ''} ${annotation.is_correct === false ? 'incorrect' : ''}`;
      
      contentParts.push(
        <span 
          key={`annotation-${annotation.id}`}
          className={highlightClass}
          onClick={() => selectAnnotation(annotation)}
          data-annotation-id={annotation.id}
        >
          {content.substring(annotation.start_offset, annotation.end_offset)}
        </span>
      );
      
      lastIndex = annotation.end_offset;
    });
    
    // Add remaining text
    if (lastIndex < content.length) {
      contentParts.push(content.substring(lastIndex));
    }
    
    return contentParts;
  };

  if (loading) {
    return <p>Loading document...</p>;
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (!document) {
    return <Alert variant="warning">Document not found</Alert>;
  }

  return (
    <div>
      <KeyboardShortcuts 
        annotations={annotations}
        selectedAnnotation={selectedAnnotation}
        setSelectedAnnotation={selectAnnotation}
        provideFeedback={provideFeedback}
        createAnnotation={createAnnotation}
        updateAnnotation={updateAnnotation}
        selectedText={selectedText}
        annotationText={annotationText}
      />
      
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>{document.title}</h2>
        <Button variant="secondary" onClick={() => navigate('/documents')}>
          Back to Documents
        </Button>
      </div>
      
      {document.source && (
        <p className="text-muted mb-4">
          Source: {document.source}
        </p>
      )}
      
      <Row>
        <Col md={8}>
          <div className="annotation-container mb-4">
            <div 
              ref={textContentRef}
              className="text-content"
              onMouseUp={handleTextSelection}
              onTouchEnd={handleTextSelection}
            >
              {renderDocumentContent()}
            </div>
          </div>
          
          <div className="keyboard-shortcuts">
            <small>
              <strong>Keyboard Shortcuts:</strong> 
              <br />
              Next: <kbd>J</kbd> | 
              Previous: <kbd>K</kbd> | 
              Save: <kbd>Ctrl+S</kbd> | 
              Correct: <kbd>C</kbd> | 
              Incorrect: <kbd>X</kbd>
            </small>
          </div>
        </Col>
        
        <Col md={4}>
          <div className="annotation-sidebar">
            {selectedText ? (
              <Card className="annotation-form mb-4">
                <Card.Body>
                  <Card.Title>New Annotation</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">
                    Selected text: "{selectedText}"
                  </Card.Subtitle>
                  
                  <Form.Group className="mb-3">
                    <Form.Label>Annotation</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={annotationText}
                      onChange={(e) => setAnnotationText(e.target.value)}
                      placeholder="Enter your annotation..."
                    />
                  </Form.Group>
                  
                  <Form.Group className="mb-3">
                    <Form.Label>Category (Optional)</Form.Label>
                    <Form.Select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                    >
                      <option value="">Select a category</option>
                      <option value="Grammar">Grammar</option>
                      <option value="Factual Error">Factual Error</option>
                      <option value="Style">Style</option>
                      <option value="Clarity">Clarity</option>
                      <option value="Other">Other</option>
                    </Form.Select>
                  </Form.Group>
                  
                  <div className="d-flex justify-content-end">
                    <Button 
                      variant="primary" 
                      onClick={createAnnotation}
                    >
                      Save Annotation
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            ) : selectedAnnotation ? (
              <Card className="annotation-form mb-4">
                <Card.Body>
                  <Card.Title>Edit Annotation</Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">
                    Selected text: "{selectedAnnotation.selected_text}"
                  </Card.Subtitle>
                  
                  <Form.Group className="mb-3">
                    <Form.Label>Annotation</Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={3}
                      value={annotationText}
                      onChange={(e) => setAnnotationText(e.target.value)}
                      placeholder="Enter your annotation..."
                    />
                  </Form.Group>
                  
                  <Form.Group className="mb-3">
                    <Form.Label>Category (Optional)</Form.Label>
                    <Form.Select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                    >
                      <option value="">Select a category</option>
                      <option value="Grammar">Grammar</option>
                      <option value="Factual Error">Factual Error</option>
                      <option value="Style">Style</option>
                      <option value="Clarity">Clarity</option>
                      <option value="Other">Other</option>
                    </Form.Select>
                  </Form.Group>
                  
                  <div className="d-flex justify-content-between">
                    <Button 
                      variant="outline-danger" 
                      onClick={() => setSelectedAnnotation(null)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      variant="primary" 
                      onClick={updateAnnotation}
                    >
                      Update Annotation
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            ) : null}
            
            <AnnotationFilter onFilterChange={handleFilterChange} />
            
            <div className="d-flex justify-content-between align-items-center mb-3">
              <h4>Annotations ({filteredAnnotations.length})</h4>
              <AnnotationSorter 
                annotations={filteredAnnotations} 
                onSortChange={handleSortChange} 
              />
            </div>
            
            {filteredAnnotations.length === 0 ? (
              <p className="text-muted">No annotations match the current filters.</p>
            ) : (
              filteredAnnotations.map(annotation => (
                <Card key={annotation.id} className="mb-3">
                  <Card.Body>
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <div>
                        <Badge 
                          bg={annotation.is_correct === true ? 'success' : annotation.is_correct === false ? 'danger' : 'secondary'}
                          className="me-2"
                        >
                          {annotation.is_correct === true ? 'Correct' : annotation.is_correct === false ? 'Incorrect' : 'Pending'}
                        </Badge>
                        {annotation.category && (
                          <Badge bg="info" className="me-2">
                            {annotation.category}
                          </Badge>
                        )}
                      </div>
                      <div>
                        <Button 
                          variant="link" 
                          size="sm" 
                          className="p-0 me-2"
                          onClick={() => selectAnnotation(annotation)}
                        >
                          <FaEdit />
                        </Button>
                        <Button 
                          variant="link" 
                          size="sm" 
                          className="p-0 text-danger"
                          onClick={() => deleteAnnotation(annotation.id)}
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </div>
                    
                    <Card.Text className="mb-2">
                      <strong>Text:</strong> "{annotation.selected_text}"
                    </Card.Text>
                    
                    <Card.Text className="mb-3">
                      <strong>Annotation:</strong> {annotation.annotation_text || <em>No annotation provided</em>}
                    </Card.Text>
                    
                    <div className="feedback-buttons">
                      <Button 
                        variant={annotation.is_correct === true ? "success" : "outline-success"} 
                        size="sm"
                        onClick={() => provideFeedback(annotation.id, true)}
                      >
                        <FaCheck /> Correct
                      </Button>
                      <Button 
                        variant={annotation.is_correct === false ? "danger" : "outline-danger"} 
                        size="sm"
                        onClick={() => provideFeedback(annotation.id, false)}
                      >
                        <FaTimes /> Incorrect
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              ))
            )}
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default DocumentView;
