import React, { useState, useEffect } from 'react';
import { Dropdown, ButtonGroup, Button } from 'react-bootstrap';
import { FaSort, FaSortAlphaDown, FaSortAlphaUp, FaSortNumericDown, FaSortNumericUp } from 'react-icons/fa';

function AnnotationSorter({ annotations, onSortChange }) {
  const [sortField, setSortField] = useState('created_at');
  const [sortDirection, setSortDirection] = useState('desc');

  useEffect(() => {
    const sortedAnnotations = sortAnnotations(annotations, sortField, sortDirection);
    onSortChange(sortedAnnotations);
  }, [annotations, sortField, sortDirection]);

  const sortAnnotations = (annotations, field, direction) => {
    return [...annotations].sort((a, b) => {
      let comparison = 0;
      
      switch (field) {
        case 'created_at':
          comparison = new Date(a.created_at) - new Date(b.created_at);
          break;
        case 'selected_text':
          comparison = a.selected_text.localeCompare(b.selected_text);
          break;
        case 'annotation_text':
          const aText = a.annotation_text || '';
          const bText = b.annotation_text || '';
          comparison = aText.localeCompare(bText);
          break;
        case 'is_correct':
          // Sort null values last
          if (a.is_correct === null && b.is_correct !== null) return 1;
          if (a.is_correct !== null && b.is_correct === null) return -1;
          if (a.is_correct === b.is_correct) return 0;
          return a.is_correct ? -1 : 1;
          break;
        default:
          comparison = 0;
      }
      
      return direction === 'asc' ? comparison : -comparison;
    });
  };

  const handleSortChange = (field) => {
    if (field === sortField) {
      // Toggle direction if same field
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // Set new field and default direction
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field) => {
    if (sortField !== field) return <FaSort />;
    
    switch (field) {
      case 'created_at':
        return sortDirection === 'asc' ? <FaSortNumericDown /> : <FaSortNumericUp />;
      case 'selected_text':
      case 'annotation_text':
        return sortDirection === 'asc' ? <FaSortAlphaDown /> : <FaSortAlphaUp />;
      case 'is_correct':
        return sortDirection === 'asc' ? <FaSortNumericDown /> : <FaSortNumericUp />;
      default:
        return <FaSort />;
    }
  };

  return (
    <div className="mb-3">
      <Dropdown as={ButtonGroup}>
        <Button variant="outline-secondary" size="sm" disabled>
          Sort by: {sortField.replace('_', ' ')} {sortDirection === 'asc' ? '↑' : '↓'}
        </Button>
        <Dropdown.Toggle split variant="outline-secondary" size="sm" id="dropdown-split-basic" />
        <Dropdown.Menu>
          <Dropdown.Item onClick={() => handleSortChange('created_at')}>
            {getSortIcon('created_at')} Date Created
          </Dropdown.Item>
          <Dropdown.Item onClick={() => handleSortChange('selected_text')}>
            {getSortIcon('selected_text')} Selected Text
          </Dropdown.Item>
          <Dropdown.Item onClick={() => handleSortChange('annotation_text')}>
            {getSortIcon('annotation_text')} Annotation Text
          </Dropdown.Item>
          <Dropdown.Item onClick={() => handleSortChange('is_correct')}>
            {getSortIcon('is_correct')} Feedback Status
          </Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default AnnotationSorter;
